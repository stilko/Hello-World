import java.util.Scanner;

/**
 * Created by User on 20.3.2016 г..
 */
public class CalculateExpressions {
    public static void main(String[] args) {
        Scanner cs = new Scanner(System.in);
        double a = cs.nextDouble();
        Scanner cs1 = new Scanner(System.in);
        double b = cs1.nextDouble();
        Scanner cs2 = new Scanner(System.in);
        double c = cs2.nextDouble();
        double secondPart = (a + b +c)/(Math.sqrt(c));
        double firstFormula =(a*a + b*b)/(a*a - b*b);
        double first = Math.pow(firstFormula,secondPart);
        double secondFomrula = (a*a + b*b - c*c*c);
        double second2 = a -b;
        double second = Math.pow(secondFomrula,second2);
        double average = ((a + b + c)/3) - ((first + second)/2);
        System.out.printf("F1 result: %.2f F2 result: %.2f Diff:%.2f",first,second,average);

    }
}
