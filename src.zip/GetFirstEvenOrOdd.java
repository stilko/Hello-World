import java.util.Scanner;

/**
 * Created by User on 22.3.2016 г..
 */
public class GetFirstEvenOrOdd {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        String entered = console.nextLine();
        String[] parts = entered.split(" ");
        int n = Integer.parseInt(parts[1]);
        String line = console.nextLine();
        String[] numb = line.split(" ");
        if (parts[2].equals("odd")) {
            for (int i = 0; i <= n + 1; i++) {
                int number = Integer.parseInt(numb[i]);
                if (number % 2 != 0) {
                    System.out.print(number + " ");
                }
                if ((line.length() / 2)== i) {
                    break;
                }
            }
        }
        else if (parts[2].equals("even")) {
            for (int i = 0; i <= n + 1; i++) {
                int number = Integer.parseInt(numb[i]);
                if (number % 2 == 0) {
                    System.out.print(number + " ");
                }
                if ((line.length() / 2)== i) {
                    break;
                }
            }
        }
    }
}

