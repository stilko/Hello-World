import java.util.Scanner;

/**
 * Created by User on 21.3.2016 г..
 */
public class Pairs {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        String line = console.nextLine();
        String[] a = line.split(" ");
        if ((line.length() / 2) != 0){

        for (int i = 0; i < line.length() / 2; i++) {

            int first = Integer.parseInt(a[i]);
            int second = Integer.parseInt(a[i + 1]);
            if ((first % 2 == 0) && (second % 2 == 0)) {

                System.out.printf("%n%d , %d -> Both are even", first, second);
            } else if ((first % 3 == 0) && (second % 3 == 0)) {

                System.out.printf("  %n%d , %d -> Both are odd", first, second);
            } else {
                System.out.printf("%n%d , %d -> different", first, second);
            }
            i++;
        }
        }
        else {
            System.out.println("inalid lenght");
        }
    }
}