import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 * Created by User on 21.3.2016 г..
 */
public class RandomizeNumbers {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        int n = console.nextInt();
        int m = console.nextInt();
        int smaller = Math.min(n, m);
        int bigger = Math.max(n, m);
        List<Integer> number = new ArrayList<>();
        for (int i = smaller; i <= bigger; i++) {
            number.add(i);
            Collections.shuffle(number);
        }
        for (int item : number) {
            System.out.print(item + " ");

        }
    }
}

