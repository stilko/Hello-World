import java.util.Scanner;

public class TriangleAria {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        String firstValue = console.nextLine();
        String [] firstPart = firstValue.split((" "));
        int first =Integer.parseInt(firstPart[0]);
        int second =Integer.parseInt(firstPart[1]);
        Scanner cs2 = new Scanner(System.in);
        String secondValue = cs2.nextLine();
        String [] secondPart = secondValue.split((" "));
        int third =Integer.parseInt(secondPart[0]);
        int fourth =Integer.parseInt(secondPart[1]);
        Scanner cs3= new Scanner(System.in);
        String thirdValue = cs3.nextLine();
        String [] thirdPart = thirdValue.split((" "));
        int fifth =Integer.parseInt(thirdPart[0]);
        int sixth =Integer.parseInt(thirdPart[1]);

        int result = (first*(fourth - sixth) + third*(sixth - second) +fifth*(second - fourth))/2;
        if (result <= 0){

            result= result * (-1);
        }
        System.out.println(result);
    }
}